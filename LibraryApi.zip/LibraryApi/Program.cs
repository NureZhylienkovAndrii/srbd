﻿using Dapper;
using Microsoft.Data.SqlClient;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

app.UseSwagger();
app.UseSwaggerUI();

string connStr = builder.Configuration.GetConnectionString("LibraryDb");

app.MapGet("/api/books/{id:int}", async (int id) =>
{
    await using var conn = new SqlConnection(connStr);
    await conn.OpenAsync();

    var book = await conn.QuerySingleOrDefaultAsync<BookDetail>(
        @"SELECT b.BookID, b.Title, b.Author, b.Publisher, b.Price, 
                 b.Quantity, b.SectionID, s.Name AS SectionName
          FROM Books b
          LEFT JOIN Sections s ON b.SectionID = s.SectionID
          WHERE b.BookID = @id",
        new { id });

    if (book is null)
        return Results.NotFound(new { message = "Book not found" });

    var loans = (await conn.QueryAsync<LoanDto>(
        @"SELECT LoanID, ReceiptNo, BookID, LoanDate, Quantity
          FROM Loans
          WHERE BookID = @id
          ORDER BY LoanDate, ReceiptNo",
        new { id })).ToList();

    return Results.Ok(new { book, loans });
})
.WithName("GetBookDetail");

app.MapGet("/api/functions/top-receipt", async (string publisher) =>
{
    await using var conn = new SqlConnection(connStr);
    await conn.OpenAsync();

    try
    {
        var receipt = await conn.ExecuteScalarAsync<int?>(
            "SELECT dbo.fn_TopReceiptByPublisher(@publisher)",
            new { publisher });

        return Results.Ok(new { publisher, TopReceipt = receipt ?? -1 });
    }
    catch (SqlException ex)
    {
        return Results.Json(new { error = ex.Message }, statusCode: 500);
    }
})
.WithName("GetTopReceipt");

app.MapGet("/api/functions/section-top-book", async (int sectionId) =>
{
    await using var conn = new SqlConnection(connStr);
    await conn.OpenAsync();

    try
    {
        var rows = await conn.QueryAsync(
            "SELECT * FROM dbo.fn_GetSectionTopBook(@sectionID)",
            new { sectionID = sectionId });

        return Results.Ok(rows);
    }
    catch (SqlException ex)
    {
        return Results.Json(new { error = ex.Message }, statusCode: 500);
    }
})
.WithName("GetSectionTopBook");

app.MapGet("/api/functions/sales-of-n-book", async (int sectionId, int n) =>
{
    await using var conn = new SqlConnection(connStr);
    await conn.OpenAsync();

    try
    {
        var rows = await conn.QueryAsync(
            "SELECT * FROM dbo.fn_GetSalesOfNBook(@SectionID, @N)",
            new { SectionID = sectionId, N = n });

        return Results.Ok(rows);
    }
    catch (SqlException ex)
    {
        return Results.Json(new { error = ex.Message }, statusCode: 500);
    }
})
.WithName("GetSalesOfNBook");

app.MapDelete("/api/books/{id:int}", async (int id) =>
{
    await using var conn = new SqlConnection(connStr);
    await conn.OpenAsync();

    using var tx = await conn.BeginTransactionAsync();

    try
    {
        var rows = await conn.ExecuteAsync(
            "DELETE FROM Books WHERE BookID = @id",
            new { id }, tx);

        await tx.CommitAsync();

        return Results.Ok(new { deleted = rows });
    }
    catch (SqlException ex)
    {
        await tx.RollbackAsync();

        if (ex.Number == 50000)
            return Results.Json(new { error = ex.Message }, statusCode: 400);

        return Results.Json(new { error = ex.Message }, statusCode: 500);
    }
})
.WithName("DeleteBook");

app.Run();

record BookDetail(int BookID, string Title, string Author, string Publisher,
                  decimal Price, int Quantity, int SectionID, string SectionName);

record LoanDto(int LoanID, int ReceiptNo, int BookID, DateTime LoanDate, int Quantity);
